import 'package:flutter/material.dart';

class Calculos extends StatelessWidget {
 
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: new Text("Calculos nutricionales"),
      ),
      body: Center(
        child:  Text("Calculos nutricionales")
      )
    );
  }
}
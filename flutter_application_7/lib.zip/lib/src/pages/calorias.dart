import 'package:flutter/material.dart';

class Calorias extends StatelessWidget {
 
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: new Text("Consultar Calorias"),
      ),
      body: Center(
        child:  Text("Consultar Calorias")
      )
    );
  }
}
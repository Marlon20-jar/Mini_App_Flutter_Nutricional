import 'package:flutter/material.dart';



class Medidas extends StatelessWidget {
 
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: new Text("Mis medidas"),
      ),
      body: Center(
        child:  Text("Mis medidas")
      )
    );
  }
}
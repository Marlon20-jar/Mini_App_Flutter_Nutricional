import 'package:flutter/material.dart';



class HomePage extends StatelessWidget {

  Widget build(BuildContext context){
    return new Scaffold(
          body: Container(
            padding: EdgeInsets.only(
              top: 320,
              bottom: 100,
              right: 100,
              left: 100
            ),
            decoration: BoxDecoration(
              color: Colors.green,
                image: DecorationImage(
                    image: AssetImage('assets/nutri.png'),
                    alignment: Alignment.topCenter)),
  child: Column(
              children: <Widget>[
                  Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Column(
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.all(3),
                          child: RaisedButton(
                            color: Colors.white,
                            shape: new RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0)),
                            onPressed: () {
                              Navigator.pushNamed(context, "/medidas");
                            },
                            child: SizedBox(
                              width: 250,
                              height: 100,
                              
                              child: Center(
                                child: Text("Mis medidas",
                                    textAlign: TextAlign.center),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                     Column(
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.all(3),
                          child: RaisedButton(
                            color: Colors.white,
                            shape: new RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0)),
                            onPressed: () {
                              Navigator.pushNamed(context, "/calculos");
                            },
                            child: SizedBox(
                              width: 250,
                              height: 100,
                              child: Center(
                                child: Text("Calculo Nutricional",
                                    textAlign: TextAlign.center),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    Column(
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.all(3),                          
                          child: RaisedButton(                           
                            color: Colors.white,
                            shape: new RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0)),
                            onPressed: () {
                              Navigator.pushNamed(context, "/calorias");
                            },
                            child: SizedBox(
                              width: 250,
                              height: 100,
                              child: Center(
                                child: Text("Consultar Calorias",
                                    textAlign: TextAlign.center),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ]
                  )               
              ]
              )
          )   
       );
  }
}